window.c = {
    name: 'c',
}
