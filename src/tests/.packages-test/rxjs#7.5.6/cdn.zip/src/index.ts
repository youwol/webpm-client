export * from "rxjs";
export * as operators from "rxjs/operators";
import * as rxjs from "rxjs";
import * as operators from "rxjs/operators";

window["rxjs_APIv7"] = { ...rxjs, operators };
