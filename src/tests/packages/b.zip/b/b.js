window.b = {
    rootName: window['root'].name,
    aName: window['a'].name,
    name: 'b',
}
