window['root'] = { name: 'root' }
