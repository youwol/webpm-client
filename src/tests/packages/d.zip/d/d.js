window.a = {
    rootName: window['root'].name,
    name: 'a',
    addOn: [],
}
