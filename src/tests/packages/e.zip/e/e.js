window.e = {
    rootName: window['root'].name,
    name: 'e',
    addOn: [],
}
